# Modelos 3D do Barão

## Revisões

| Versão | Data | Arquivo | Estado |
| --- | --- | --- | --- |
| v001 | 30/09/2026 | [barao.glb](v001/barao.glb) | Arquivo gerado e conferido localmente; importação no Studio pendente |

A pasta `v001` contém a primeira entrega. Para a próxima revisão, crie `v002`, preserve os arquivos da anterior e acrescente uma linha nesta tabela. O Git pode acompanhar cada revisão; nenhum commit é feito automaticamente.

Cada versão guarda o modelo, atlas, imagens, coordenadas dos pivôs, relatório de validação, fontes de geração e uma cópia das referências usadas. Isso permite reproduzir a entrega mesmo se a ficha original mudar.

O conteúdo desta pasta não é carregado pelo projeto Rojo. A substituição do Barão no jogo depende da importação e da integração posteriores.

Veja os detalhes em [v001/README.md](v001/README.md).
